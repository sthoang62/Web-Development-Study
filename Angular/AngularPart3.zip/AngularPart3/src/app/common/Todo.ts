export class Todo {
  constructor (public task: string, public description: string, public active: boolean) {
  }
}
