import { Component } from '@angular/core'
import { CommonModule } from '@angular/common'
import { RouterOutlet } from '@angular/router'
import { FormsModule } from '@angular/forms'

import { Todo } from '../common/Todo'

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Todo List'
  todo: Todo = new Todo('', '', false)
  todoList: Todo[] = []
  selIndex = -1

  onSel (idx: number): void {
    this.todoList[idx].active = false
    this.selIndex = idx
    this.todoList[idx].active = true
  }

  onDel (): void {
    if (this.selIndex >= 0) {
      this.todoList.splice(this.selIndex, 1)
    }

    this.selIndex = -1
  }

  addTodo (): void {
    this.todoList.push(new Todo(this.todo.task, this.todo.description, false))
    this.todo.task = ''
    this.todo.description = ''
  }
}
